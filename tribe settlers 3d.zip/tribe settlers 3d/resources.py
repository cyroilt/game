from time import gmtime, strftime,sleep
from random import randint
from mytools import*
wood1=0
woodstats=[]
stone1=0
freepeople1=0
money1=0
people1=0
basis1=0
army1=0
scale1=1
instr=0
datawood=[]
nb=1
dltswood=[]
dltmwood=[]
dlthwood=[]
mexp1=50
levelb=1
mexpsumm=0
lastmomentwood=strftime("%H %M %S", gmtime()).split()
stats=[]
happ=0
meal1=[]
class wood():
       global wood1
       def gerer(amount):
              global lastmomentwood,dltswood,dltmwood,dlthwood,datawood
              currwood=strftime("%H %M %S", gmtime()).split()
              dltswood.append((int(currwood[0])-int(lastmomentwood[0]))*3600+(int(currwood[1])-int(lastmomentwood[1]))*60+int(currwood[2])-int(lastmomentwood[2]))
              dltmwood.append((int(currwood[0])-int(lastmomentwood[0]))*60+(int(currwood[1])-int(lastmomentwood[1])))
              dlthwood.append((int(currwood[0])-int(lastmomentwood[0])))
              datawood.append(amount)
              lastmomentwood=strftime("%H %M %S", gmtime()).split()

       def set(n):
              global wood1
              wood1=n
              wood.gerer(n)
       def change(n):
              global wood1
              wood1+=n
              wood.gerer(wood1)
       def get():
              global wood1
              return wood1
       def getger(t='s'):
              global datawood,dltswood,dltmwood,dlthwood
              if t=='s':
                     return dltswood,datawood
class stone():
       global stone1
       def set(n):
              global stone1
              stone1=n
       def change(n):
              global stone1
              stone1+=n
       def get():
              global stone1
              return stone1
class money():
       global money1
       def set(n):
              global money1
              money1=n
       def change(n):
              global money1
              money1+=n
       def get():
              global money1
              return money1
class people():
       global people1
       def set(n):
              global people1
              people1=n
       def change(n):
              global people1,freepeople1
              people1+=n
              freepeople1+=n
       def get():
              global people1
              return people1
class freepeople():
       global freepeople1

       def set(n):
              global freepeople1
              freepeople1=n
       def change(n):
             global freepeople1
             freepeople1+=n
       def get():
              global freepeople1
              return freepeople1
class instruments():
       global instr

       def set(n):
              global instr
              instr=n
       def change(n):
             global instr
             instr+=n
       def get():
              global instr
              return instr
class happieness():
       global happ

       def set(n):
              global happ
              happ=n
       def change(n):
             global happ
             happ+=n
       def get():
              global happ
              return happ
class levels():
       global basis1,army1
       def changebasis(n):
              global basis1,nb,mexp1,levelb,mexpsumm
              basis1+=n
              mexpsumm+=n
              if mexpsumm>mexp1:

                     mexp1=round(mexp1*1.25)
                     mexpsumm=0
                     levelb+=1
                     updatebar(nb,mexpsumm,mexp1,levelb)
              else:
                     updatebar(nb,mexpsumm,mexp1,levelb)
       def getbasis():
              global levelb
              return levelb
       def get_bexp():
              global basis1
              return basis1
class meal():
       global meal1

       def set(n):
              global meal1
              meal1=n
       def change(n):
             global meal1
             meal1+=n
       def get():
              global meal1
              return meal1
class scale():
       def get():
              global scale1
              return scale1
       def change(n):
              global scale1
              scale1*=n
def get_all():
       return wood.get(),stone.get(),money.get(),instruments.get(),levels.get_bexp(),people.get(),freepeople.get(),meal.get()
def runexptimer():
       while True:
              time.sleep(0.01)
              levels.changebasis(100)
knk={'wood':wood,'stone':stone,'money':money,'freepeople':freepeople,'level':levels,'meal':meal,'instruments':instruments}
def checkcosts(costs):
    level=True
    for i in costs.keys():
        for j in knk.keys():
            if i==j and costs[i]<=knk[j].get():
                level*=True
            elif i==j and not(costs[i]<=knk[j].get()):
                level*=False
    return level
def deletecost(costs):
    for i in costs.keys():
        for j in knk.keys():
            if i==j :
                knk[j].change(-1*costs[i])
    print(get_all())
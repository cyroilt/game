from validate_email import validate_email
is_valid = validate_email("cyroil31@gmail.com", verify=True)
print(is_valid)